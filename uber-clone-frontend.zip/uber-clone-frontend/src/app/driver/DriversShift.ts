export interface DriversShift {
  id: number,
  start: Date,
  end: Date
}
