export const environment = {
  apiURL: "http://localhost:8080/api/"
}
