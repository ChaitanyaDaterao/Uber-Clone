export class SimpleRide {
  rute : string
  startEnd : string
  price : string

  constructor(rute: string, startEnd: string, price: string,) {
    this.rute = rute;
    this.startEnd = startEnd;
    this.price = price;
  }

}
