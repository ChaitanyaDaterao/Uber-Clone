export interface UserRetrieved {
  id : number,
  name : string,
  surname : string,
  profilePicture : string,
  telephoneNumber : string,
  email : string,
  address : string

}
