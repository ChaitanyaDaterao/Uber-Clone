export class DateStartEnd {
  start: Date
  end: Date

  constructor(start: Date, end: Date) {
    this.start = start;
    this.end = end;
  }

}
