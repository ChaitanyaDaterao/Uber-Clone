import {Location} from "./Location";

export interface Vehicle {
  id: number;
  currentLocation: Location;
}
