import { VehicleWithOnlyLocation } from './VehicleWithOnlyLocation';

export interface Ride {
  id: number;
  vehicle: VehicleWithOnlyLocation;
}
