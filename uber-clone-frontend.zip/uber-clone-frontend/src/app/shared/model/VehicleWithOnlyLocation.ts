export interface VehicleWithOnlyLocation {
  id: number;
  latitude: number;
  longitude: number;
}
