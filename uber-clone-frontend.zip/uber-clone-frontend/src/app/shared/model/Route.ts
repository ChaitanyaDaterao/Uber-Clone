import {Location} from "./Location";

export interface Route {
  departure : Location,
  destination : Location
}
