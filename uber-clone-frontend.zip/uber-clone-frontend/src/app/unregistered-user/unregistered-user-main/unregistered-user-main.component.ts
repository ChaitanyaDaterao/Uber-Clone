import { Component } from '@angular/core';


@Component({
  selector: 'app-unregistered-user-main',
  templateUrl: './unregistered-user-main.component.html',
  styleUrls: ['./unregistered-user-main.component.css','../../app.component.css']
})
export class UnregisteredUserMainComponent {

  constructor() {
  }

}
